<!--This is the group work of GAF DIT 2016 INTERNSHIP GROUP(SUB GROUP 3).-->
<!--All syntaxes are well documented for reusability-->
<!--
    Group members
    
    codes: Enoch Sowah
    codes(assistant): David Tettey, Godwin Dorglo, Louis Dadzie
    graphics: Eric Samoah
    graphics(assistant): Benedict Mensah
    
-->
<html>
    <head>
         <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" type="text/css" href="css/material.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
            .navbar{
                background: transparent;
                border: 1px solid transparent;
                transition: all 0.4s ease-in-out;
            }
            .navbar-brand,#menu{ 
                color: #111;
                font-weight: bold;
            }
            .item{
                background: #333;
                text-align: center;
                height: 550px !important;
                
            }
            .carousel{
                position: fixed !important;
                width:110%;
                margin-left: -5%;
                position: relative;
                z-index: -100;
            }
            .carousel-caption{
                color: #111;
            }
            #img{
                height: 100%;width: 100%;
            }
            .mainBody{
                margin-top:560px;
                background: #fff;
            }
            #introDiv div{
                width: 30%;
                margin-left: 2%;
                border: 1px solid #c0c0c0;
            }
            #introDiv div:hover{
                transform: scale(1.03);
                box-shadow: 2px 2px 3px #c0c0c0;
            }
            #divPic{
                width: 100%;
                height: 90px;
            }
            #catRow h4{
                text-align: center;
            }
            #uniPic{
                width: 100p%;
                height: 100px;
                display: block;
            }
            #uniPic:hover{
                transform: scale(1.5) rotateY(180deg);
                transition: all 0.5s ease-in;
            }
            hr{
                width: 80%;
                margin-left: 10%;
            }
            #footerTitle{
              color: yellow;
            }
            #footerRow p,#footerRow p a{
              color: #fff;
            }
            #socImg{
                height: 20px;
                width: 20px;
            }
            #footerRow{
                background: #032E07;
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                <a class="navbar-brand" href="#"><span id="brand">GAF ONLINE SHOP</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php" id="menu" style="text-decoration:underline">Home</a></li>
                <li><a href="GOS_Shop.php" id="menu">Shop</a></li>
                <li><a href="GOS_Contact.php" id="menu">Contact Us</a></li>
                <li><a href="GOS_About.php" id="menu">About Us</a></li>
              </ul>
            </div>
          </div>
        </nav>
        
        <!--beginning of carousel slider-->
        <div class="container-fluid">
          <div id="myCarousel" class="carousel slide" data-interval="5000" data-ride="carousel">

              <ol class="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
              </ol>

              <div class="carousel-inner">
                  <div class="active item">
                      <img src="images/201209101518403488.jpg" alt="Packt" id="img">
                      <div class="carousel-caption">
                          <h6><b>UP<sup>+</sup> makes learning fun and interesting</b></h6>
                      </div>
                  </div>
                  <div class="item">
                      <img src="images/201209051143276913.jpg" alt="PacktLib" id="img">
                      <div class="carousel-caption">
                          <h6><b>Get to know more about tertiary institutions in Ghana</b></h6>
                      </div>
                  </div>
                  <div class="item">
                      <img src="images/201209100935482757.jpg" alt="Packt" id="img">
                      <div class="carousel-caption">
                          <h6><b>Get to know what's being sold or leased around campuses</b></h6>
                      </div>
                  </div>
                  <div class="item">
                      <img src="images/201312092203231843.jpg" alt="Packt" id="img">
                      <div class="carousel-caption">
                          <h6><b>Events notices never got that easier</b></h6>
                      </div>
                  </div>
              </div>

             <a class="carousel-control left" href="#myCarousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              </a>
              <a class="carousel-control right" href="#myCarousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              </a>
           </div>
      </div>
      <br /><br />
     <!--end of carousel slider-->
        
     <!--Begining of main body-->
        <div class="container-fluid mainBody"><br/><br/>
            <div class="row" id="introDiv">
                <div class="col-md-4 col-xs-12">
                    <h4>Akwaaba</h4>
                    <p>Welcome to the online shopping site of the ghana armed forces, for the ghana armed forces.<br/>
                    We have in stock all military and civilian employee apparel and accessories.
                    Please surf the site to buy what you need.</p>
                    <img src="images/welcome.jpg" alt="image" id="divPic"><br/><br/>
                </div>
                <div class="col-md-4 col-xs-12">
                    <h4>Products</h4>
                    <p>We have in stock military(army, navy, airforce) apparels such as full uniforms, caps and berets, ceremonial uniforms, officers uniforms, boots, etc. We also have in stock civilian employee uniforms such as shirts, trousers skirts and many more.</p>
                    <img src="images/available.png" alt="image" id="divPic"><br/><br/>
                </div>
                <div class="col-md-4 col-xs-12">
                    <h4>Customer Service</h4>
                    <p>We have a fast and reliable delivery system for all customers at precise destination, and vantage points for customers with inprecise destinations. We also have a very reliable customer support service which is available at each time in the day.</p>
                    <img src="images/ccare.jpg" alt="image" id="divPic"><br/><br/>
                </div>
            </div><br/><br/>
            
            <div class="row" id="catRow">
                <h4>Army Apparel</h4>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/201209100937358309.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
            </div><br/><hr>
            
            <div class="row" id="catRow">
                <h4>Navy Apparel</h4>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/201209100937358309.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
            </div><br/><hr>
            
            <div class="row" id="catRow">
                <h4>Air Force Apparel</h4>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/201209100937358309.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
            </div><br/><hr>
            
            <div class="row" id="catRow">
                <h4>Civilian Apparel</h4>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/2012090509172771.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
                <div class="col-md-3 col-xs-12">
                    <img src="images/201209100937358309.jpg" id="uniPic"><br/>
                    <p>GH&cent;200</p>
                </div>
            </div><br/><hr>
            
            <div class="row" id="footerRow">
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Contact Us</h6>
                          <p ><span class="glyphicon glyphicon-phone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-phone-alt"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-earphone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-envelope"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-globe"></span> +1111111111</p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Follow Us On Social Media</h6>
                          <p><img src="images/face%20book.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/instagram.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/linked%20in.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/twitter.png" id="socImg"><a href=""> @GAFOnlineShop</a></p>
                           <p><img src="images/youtube.png" id="socImg"><a href=""> GAF Online Shop</a></p><br>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Navigate Other Pages</h6>
                          <p><a href="index.php"> GOS Home</a></p>
                          <p><a href="GOS_Shop.php"> GOS Shop</a></p>
                          <p><a href="GOS_Contact.php"><span class="glyphicon glyphicon-asterisk"></span> GOS Contact</a></p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Copyright</h6>
                          <p>This e-commerce site is a sole property of Ghana Armed Forces.<br/>
                            No person under any condition should use any information or part of this website without the 
                            prior notice of Ghana Armed Forces.<br/>Any culprit will be dealt with accordingly.<br/>GAF &copy; 2016</p>
                        </div>
                    </div>   
        </div>
     <!--end of main body-->
    
    <script>
        $(function(){
            
            var limit = $(".navbar").height();      //get the height of the nav bar
            
            $(window).on("scroll",function(){       //add an event listener to the browser window
                
                if($(this).scrollTop() >= (limit * 11)){ //if the scrolled space >= (navbarHeight *11),
                    
                    $(".navbar").css("background","#032E07"); //change the background of the navbar to 'dirty green'
                    
                    $(".navbar-brand, #menu").css("color","#fff");// change the color of the items on navbar to white
                    
                }else{                                  //else if not so,
                    
                    $(".navbar").css("background","transparent"); //use the original style for the navbar
                    
                    $(".navbar-brand, #menu").css("color","#111");//use the original style fot items on navbar
                    
                }
            });
            
        });    
    </script>
    </body>
</html>