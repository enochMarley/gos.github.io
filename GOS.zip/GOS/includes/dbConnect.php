<?php

    $con = mysqli_connect("localhost","root","","gos");

?>

