<html>
    <head></head>
    <body>
        <h1>THIS IS THE CIVILIAN SITE</h1>
    </body>
</html>