<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/material.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script src="js/jquery-1.12.2.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/material.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="coin-slider.min.js"></script>
    <link rel="stylesheet" href="coin-slider-styles.css" type="text/css" />
    <style>
    	body{
        background-image: url("images/camobg.png");
        background-size: 200%;
        background-repeat: repeat-y;
        opacity: 0.8;
      }
        #logo{
            height: 60px;
            width: 90px;
        }
        .pageTitle p,.pageTitle p:hover{
            margin-top: 2%;
            color: #fff;
            font-size:16px; 
            background: transparent;
        }
        #drawerImg{
            width: 100%;
            margin-left: -5%;
        }
        .mdl-layout__header,#footerDiv{
            background: #032E07;
        }
        .mdl-navigation__link,.mdl-navigation__link:hover{
            background: #032E07;
            text-decoration: none;
            color: yellow;
        }
        .mdl-navigation .mdl-navigation__link{
            background: transparent;
            color: #fff;
        }
        .mdl-navigation .mdl-navigation__link:hover{
            !important background: transparent;
            color: #111;
        }
        .mdl-layout__drawer{
            background: #032E07;
        }
        #socImg{
            height: 20px;
            width: 20px;
        }
        #footerTitle{
          color: yellow;
        }
        #footerRow p,#footerRow p a{
          color: #fff;
        }
        #submenu{
            background: #fff;
            margin-top: -1%;
        }
        #submenu div div{
            margin-top: 1%;
        }
        #submenu div div p{
            font-weight: bold;
        }
        .mdl-tabs__tab-bar{
            background:#fff;
        }
        .mdl-tabs__tab{
            margin-right: 10%;
        }
        #typeDiv{
            background: #fff;
            border: 1px solid #c0c0c0;
        }
        #typeDiv:nth-child(1){
            margin-top: 2%;
        }
    </style>
</head>
<body>
	<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
        <header class="mdl-layout__header">
                <div class="mdl-layout__header-row">
                    <span class="mdl-layout-title"><a href=""><img id="logo" src="images/Ghana%20Armed%20Forces.png"></a></span>
                    <a class="mdl-navigation__link pageTitle" href="index.php"><p>GHANA ARMED FORCES<br/>ONLINE SHOP</p></a>
                    <div class="mdl-layout-spacer"></div>
                    <nav class="mdl-navigation">
                       <a class="mdl-navigation__link" href="index.php">Home</a>
                        <a class="mdl-navigation__link" href="GOS_Shop.php" style="color:yellow">Shop</a>
                        <a class="mdl-navigation__link" href="GOS_Contact.php">Contact</a>
                    </nav>
                </div>   
            </header>
    
            <div class="mdl-layout__drawer">
                <span class="mdl-layout-title">
                    <img src="images/Ghana%20Armed%20Forces.png" id="drawerImg">
                </span>
                <nav class="mdl-navigation" id="navList">
                    <a href="index.php" class="mdl-navigation__link"> Home</a>
                    <a href="GOS_Shop.php" class="mdl-navigation__link"> Shop</a>
                    <a href="GOS_Contact.php" class="mdl-navigation__link"> Contact</a>
                </nav>
            </div>
    
        <main class="mdl-layout__content">
            <div class="page-content">
                    <div class="container-fluid" id="submenu">
                        <div class="row">
                            <div class="col-md-3 col-xs-6">
                                <p>Client: <?php echo $_SESSION['username']; ?></p>
                            </div>
                            <div class="col-md-3 col-xs-6">
                                <p>Total Items: </p>
                            </div>
                            <div class="col-md-3 col-xs-6">
                                <p>Total Amount: </p>
                            </div>
                            <div class="col-md-3 col-xs-6">
                                <a><p>Logout</p></a>
                            </div>
                        </div>
                </div>
                <div class="mdl-tabs mdl-js-tabs">
                    <div class="mdl-tabs__tab-bar">
                       <a href="#tab1-panel" class="mdl-tabs__tab is-active">ARMY</a>
                       <a href="#tab2-panel" class="mdl-tabs__tab">NAVY</a>
                       <a href="#tab3-panel" class="mdl-tabs__tab">AIR FORCE</a>
                    </div>
                    <div class="mdl-tabs__panel is-active" id="tab1-panel">
                        
                       <div class="container">
                           
                        <div class="row" id="typeDiv">
                            <p>Full Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Ceremonial Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                        
                        <div class="row" id="typeDiv">
                            <p>Officers Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Overall Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>T-shirts</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Boots</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Socks</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Watches</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Caps</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Berets</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                       </div>
                    </div>
                    <div class="mdl-tabs__panel" id="tab2-panel">
                        
                       <div class="container">
                           
                        <div class="row" id="typeDiv">
                            <p>Full Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Ceremonial Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                        
                        <div class="row" id="typeDiv">
                            <p>Officers Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Overall Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>T-shirts</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Boots</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Socks</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Watches</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Caps</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Berets</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                       </div>
                    </div>
                    
                    <div class="mdl-tabs__panel" id="tab3-panel">
                        
                       <div class="container">
                        <div class="row" id="typeDiv">
                            <p>Full Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Ceremonial Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                        
                        <div class="row" id="typeDiv">
                            <p>Officers Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Overall Uniforms</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>T-shirts</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Boots</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Socks</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Watches</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Caps</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                        <div class="row" id="typeDiv">
                            <p>Berets</p>
                            The uniforms will be displayed here
                        </div><br/><br/>
                           
                       </div>
                        
                    </div>
                </div>
            </div>
        </main>         
    </div>
</body>
</html>