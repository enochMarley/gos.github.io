<!--This is the group work of GAF DIT 2016 INTERNSHIP GROUP(SUB GROUP 3).-->
<!--All syntaxes are well documented for reusability-->
<!--
    Group members
    
    codes: Enoch Sowah
    codes(assistant): David Tettey, Godwin Dorglo, Louis Dadzie
    graphics: Eric Samoah
    graphics(assistant): Benedict Mensah
    
-->
<!doctype>
<?php 
    include("functions/shopPageFunctions.php"); 
    include("functions/militaryPage.php"); 
    include("functions/navyPage.php"); 
    include("functions/airforcePage.php"); 
    include("functions/civilianPage.php"); 
?>
<html>
    <head>
        <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" href="css/material.min.css">
        <link rel="stylesheet" type="text/css" href="css/material.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/material.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
            .navbar{
                background: #fff;
                border: 1px solid transparent;
                transition: all 0.4s ease-in-out;
            }
            .navbar-brand,#menu{ 
                color: #111;
                font-weight: bold;
            }
            .mainBody{
                margin-top:8%;
                background: #fff;
            }
            #footerTitle{
              color: yellow;
            }
            #footerRow p,#footerRow p a{
              color: #fff;
            }
            #socImg{
                height: 20px;
                width: 20px;
            }
            #footerRow{
                background: #032E07;
            }
            #prodImg{
                width: 100%;
            }
            #prodDiv{
                border: 1px solid #c0c0c0;
                width: 30%;
                margin-left: 2%;
                margin-bottom: 2%;
                background: #c0c0c0;
                border-radius: 5px;
            }
            #seachInput{
                margin-top: 2%;
                border-radius: 7px;
                color: #111;
                text-align: center;
                border: 1px solid #111;
            }
            #prodDiv:hover{
                transform: scale(1.05);
                box-shadow: 2px 2px 3px #111;
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                <a class="navbar-brand" href="#"><span id="brand">GAF ONLINE SHOP</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav">
                  <li><a href="#" id="menu" style="font-size: 25px;"><span class="glyphicon glyphicon-shopping-cart"></span> <sup><span class="badge"><span id="totalItem"></span></span></sup></a></li>
                  <li><a href="#" id="menu" style="font-size: 25px;"><span class="glyphicon glyphicon-credit-card"></span> <sup><span class="badge">GH&cent; <span id="totalPrice"></span></span></sup></a></li>
                <li><a href="shopCart.php" id="menu">Go To Cart</a></li> 
                <li><a href="checkOut.php" id="menu">Checkout</a></li> 
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><input type='text' name='search' placeholder='Search For Item' id="seachInput"></li>
                <li><a href="index.php" id="menu">Home</a></li>
                <li><a href="GOS_Shop.php" id="menu" style="text-decoration:underline">Shop</a></li>
                <li><a href="GOS_Contact.php" id="menu">Contact Us</a></li>
                <li><a href="GOS_About.php" id="menu">About Us</a></li>
              </ul>
            </div>
          </div>
        </nav>
        
        
        
     <!--Begining of main body-->
        <div class="container-fluid mainBody"><br/><br/>
            <div class="mdl-tabs mdl-js-tabs">
                <div class="mdl-tabs__tab-bar">
                   <a href="#tab1-panel" class="mdl-tabs__tab is-active">ARMY</a>
                   <a href="#tab2-panel" class="mdl-tabs__tab">NAVY</a>
                   <a href="#tab3-panel" class="mdl-tabs__tab">AIR FORCE</a>
                   <a href="#tab4-panel" class="mdl-tabs__tab">CIVILIAN EMPLOYEES</a>
                </div>
                <div class="mdl-tabs__panel is-active" id="tab1-panel">
                        
                   <div class="container">
                       <h5>Uniforms</h5>
                       <br/>
                       <?php
                            showMilitaryUniforms();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Shoes &amp; Boots</h5>
                       <br/>
                       <?php
                            showMilitaryShoes();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showMilitarySocks();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showMilitaryAccessories();
                       ?>
                       <br/>
                   </div><br/>
                </div>
                
                <div class="mdl-tabs__panel " id="tab2-panel">
                        
                   <div class="container">
                       <h5>Uniforms</h5>
                       <br/>
                       <?php
                            showNavyUniforms();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Shoes &amp; Boots</h5>
                       <br/>
                       <?php
                            showNavyShoes();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showNavySocks();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showNavyAccessories();
                       ?>
                       <br/>
                   </div><br/>
                    
                </div>
                
                <div class="mdl-tabs__panel" id="tab3-panel">
                        
                   <div class="container">
                       <h5>Uniforms</h5>
                       <br/>
                       <?php
                            showAirforceUniforms();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Shoes &amp; Boots</h5>
                       <br/>
                       <?php
                            showAirforceShoes();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showAirforceSocks();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Socks &amp; Caps</h5>
                       <br/>
                       <?php
                            showAirforceAccessories();
                       ?>
                       <br/>
                   </div><br/>
                    
                </div>
                
                <div class="mdl-tabs__panel" id="tab4-panel">
                        
                   <div class="container">
                       <h5>Uniforms</h5>
                       <br/>
                       <?php
                            showCivilianUniforms();
                       ?>
                       <br/>
                   </div><br/>
                    <hr>
                    <div class="container">
                        <h5>Shoes &amp; Boots</h5>
                       <br/>
                       <?php
                            showCivilianShoes();
                       ?>
                       <br/>
                   </div><br/>
                </div>
            </div>
        
            
            <div class="row" id="footerRow">
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Contact Us</h6>
                          <p ><span class="glyphicon glyphicon-phone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-phone-alt"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-earphone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-envelope"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-globe"></span> +1111111111</p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Follow Us On Social Media</h6>
                          <p><img src="images/face%20book.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/instagram.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/linked%20in.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/twitter.png" id="socImg"><a href=""> @GAFOnlineShop</a></p>
                           <p><img src="images/youtube.png" id="socImg"><a href=""> GAF Online Shop</a></p><br>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Navigate Other Pages</h6>
                          <p><a href="index.php"> GOS Home</a></p>
                          <p><a href="GOS_Shop.php"> GOS Shop</a></p>
                          <p><a href="GOS_Contact.php"><span class="glyphicon glyphicon-asterisk"></span> GOS Contact</a></p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Copyright</h6>
                          <p>This e-commerce site is a sole property of Ghana Armed Forces.<br/>
                            No person under any condition should use any information or part of this website without the 
                            prior notice of Ghana Armed Forces.<br/>Any culprit will be dealt with accordingly.<br/>GAF &copy; 2016</p>
                        </div>
                    </div>   
        </div>
     <!--end of main body-->
    
    <script>
        $(function(){
            
            var limit = $(".navbar").height();      //get the height of the nav bar
            
            $(window).on("scroll",function(){       //add an event listener to the browser window
                
                if($(this).scrollTop() >= limit){ //if the scrolled space >= (navbarHeight *11),
                    
                    $(".navbar").css("background","#032E07"); //change the background of the navbar to 'dirty green'
                    
                    $(".navbar-brand, #menu").css("color","#fff");// change the color of the items on navbar to white
                    
                }else{                                  //else if not so,
                    
                    $(".navbar").css("background","#fff"); //use the original style for the navbar
                    
                    $(".navbar-brand, #menu").css("color","#111");//use the original style fot items on navbar
                    
                }
            });
            
        });
        
        
        
        function getTotalAmount() {
			$.ajax({
				method: 'GET',
				url: "functions/getTotalAmount.php",
				success: function(data) {
					
					$("#totalPrice").html(data);
				},
				error: function(error) {
					console.log(error);
				}
			});
		}
        
        function getTotalItems() {
			$.ajax({
				method: 'GET',
				url: "functions/getTotalItems.php",
				success: function(data) {
					
					$("#totalItem").html(data);
				},
				error: function(error) {
					console.log(error);
				}
			});
		}
		
		getTotalAmount();
		getTotalItems();
	
	   
        function sendToCart(id){

                var itemId = $("input#itemId"+id).val();
                var itemTitle = $("input#itemTitle"+id).val();
                var itemPrice = $("input#itemPrice"+id).val();
                var itemImg = $("input#itemImg"+id).val();
                var userIp = $("input#userIp"+id).val();
                var quantity = $("input#qInput"+id).val();
                var itemSize = $("select#itemSize"+id).val();
                /*if(quantity != "" && itemSize != null){
                    $("#add"+id).html("Added to cart");
                }else if(itemSize == null){
                    alert("Please choose item size");
                }else{*/
            
                $.ajax({
                    method: "POST",
                    url: "functions/sendTotalAmount.php",
                    data: {"itemId":itemId,"itemTitle":itemTitle,"itemPrice":itemPrice,"itemImage":itemImg,"userIp":userIp,"itemQuantity":quantity,"itemSize":itemSize},
                    success: function(success){
                        getTotalAmount();
		                getTotalItems();
                        
                    },
                    error: function(error){console.log(error)}
                });
                //}
            
        }
        
    </script>
    </body>
</html>
