<!--This is the group work of GAF DIT 2016 INTERNSHIP GROUP(SUB GROUP 3).-->
<!--All syntaxes are well documented for reusability-->
<!--
    Group members
    
    codes: Enoch Sowah
    codes(assistant): David Tettey, Godwin Dorglo, Louis Dadzie
    graphics: Eric Samoah
    graphics(assistant): Benedict Mensah
    
-->
<!doctype>
<?php include("functions/shopPageFunctions.php"); ?>
<html>
    <head>
        <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" href="css/material.min.css">
        <link rel="stylesheet" type="text/css" href="css/material.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/material.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
            .navbar{
                background: #fff;
                border: 1px solid transparent;
                transition: all 0.4s ease-in-out;
            }
            .navbar-brand,#menu{ 
                color: #111;
                font-weight: bold;
            }
            .mainBody{
                margin-top:5%;
                background: #fff;
            }
            #footerTitle{
              color: yellow;
            }
            #footerRow p,#footerRow p a{
              color: #fff;
            }
            #socImg{
                height: 20px;
                width: 20px;
            }
            #footerRow{
                background: #032E07;
            }
            #prodImg{
                width: 50%;
            }
            #prodDiv{
                border: 1px solid #c0c0c0;
                width: 30%;
                margin-left: 2%;
            }
            #qInput{
                width: 50%;
            }
            #seachInput{
                margin-top: 2%;
                border-radius: 7px;
                color: #111;
                text-align: center;
                border: 1px solid #111;
            }
            #pageTitle{
                text-align: center;
            }
            .table-bordered{
                width: 100%;
            }
            .table-bordered tr:nth-child(1) td{
                font-weight: bold;
            }
            .table-bordered tr td{
                height: 40px;
                text-align: center;
            }
            #checkOut{
                float: right;
            }
            #loginForm{
                border: 1px solid #c0c0c0;
                border-radius: 5px;
                background: #c0c0c0;
            }
            #loginForm input{
                width: 90%;
                height: 40px;
                margin-left: 5%;
            }
            #loginForm select{
                width: 50%;
                margin-left: 5%;
            }
            #loginForm button{
                width: 90%;
                margin-left: 5%;
            }
            #loginForm label{
                margin-left: 5%;
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                <a class="navbar-brand" href="#"><span id="brand">GAF ONLINE SHOP</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav">
                  <li><a href="#" id="menu" style="font-size: 25px;"><span class="glyphicon glyphicon-shopping-cart"></span> <sup><span class="badge"><?php getTotalItems(); ?></span></sup></a></li>
                  <li><a href="#" id="menu" style="font-size: 25px;"><span class="glyphicon glyphicon-credit-card"></span> <sup><span class="badge">GH&cent; <?php getTotalPrice(); ?></span></sup></a></li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php" id="menu">Home</a></li>
                <li><a href="GOS_Shop.php" id="menu" style="text-decoration:underline">Shop</a></li>
                <li><a href="GOS_Contact.php" id="menu">Contact Us</a></li>
                <li><a href="GOS_About.php" id="menu">About Us</a></li>
              </ul>
            </div>
          </div>
        </nav>
        
        
        
     <!--Begining of main body-->
        <div class="container-fluid mainBody"><br/><br/>
            
            <div class="row">
                <h4 id="pageTitle">Please login with your full name and service number to proceed to check out</h4><br/>
                <div class="col-md-4"></div>
                <div class="col-md-4 col-xs-12">
                    <form id="loginForm" action="" method="post">
                        <h6 id="pageTitle">USER LOGIN</h6>
                        <label>Full Name:</label><br/>
                        <input type="text" name="fullName" required><br/><br/>
                        
                        <label>Service Number:</label><br/>
                        <input type="number" name="serviceNumber" required><br/><br/><br/>
                        
                        <button type="submit">Login</button><br/><br/><br/>
                        <p id="errMsg"></p>
                    </form>
                    <br/><br/><br><br><br/><br/>
                </div>
                <div class="col-md-4"></div>
            </div>
        
            <div class="row" id="footerRow">
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Contact Us</h6>
                          <p ><span class="glyphicon glyphicon-phone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-phone-alt"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-earphone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-envelope"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-globe"></span> +1111111111</p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Follow Us On Social Media</h6>
                          <p><img src="images/face%20book.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/instagram.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/linked%20in.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/twitter.png" id="socImg"><a href=""> @GAFOnlineShop</a></p>
                           <p><img src="images/youtube.png" id="socImg"><a href=""> GAF Online Shop</a></p><br>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Navigate Other Pages</h6>
                          <p><a href="index.php"> GOS Home</a></p>
                          <p><a href="GOS_Shop.php"> GOS Shop</a></p>
                          <p><a href="GOS_Contact.php"><span class="glyphicon glyphicon-asterisk"></span> GOS Contact</a></p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Copyright</h6>
                          <p>This e-commerce site is a sole property of Ghana Armed Forces.<br/>
                            No person under any condition should use any information or part of this website without the 
                            prior notice of Ghana Armed Forces.<br/>Any culprit will be dealt with accordingly.<br/>GAF &copy; 2016</p>
                        </div>
                    </div>   
        </div>
     <!--end of main body-->
    
    <script>
        $(function(){
            
            var limit = $(".navbar").height();      //get the height of the nav bar
            
            $(window).on("scroll",function(){       //add an event listener to the browser window
                
                if($(this).scrollTop() >= (limit * 13)){ //if the scrolled space >= (navbarHeight *11),
                    
                    $(".navbar").css("background","#032E07"); //change the background of the navbar to 'dirty green'
                    
                    $(".navbar-brand, #menu").css("color","#fff");// change the color of the items on navbar to white
                    
                }else{                                  //else if not so,
                    
                    $(".navbar").css("background","#fff"); //use the original style for the navbar
                    
                    $(".navbar-brand, #menu").css("color","#111");//use the original style fot items on navbar
                    
                }
            });
            
        });    
    </script>
    </body>
</html>
<?php

    include("includes/dbConnect.php");
    $fullName = $_POST['fullName'];
    $serviceNumber = $_POST['serviceNumber'];
    
    if(isset($fullName) and isset($serviceNumber)){
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            
            $query = "select * from users where fullName = '$fullName' and serviceNumber = '$serviceNumber' ;";

            $result= mysqli_query($con,$query);

            if(mysqli_num_rows($result) > 0){

                $row = mysqli_fetch_assoc($result);

                $id = $row['userId'];

                $fName = $row['fullName'];

                $sNumber = $row['serviceNumber'];

                $rank = $row['rank'];

                if($_SERVER['REQUEST_METHOD'] == "POST"){

                    if($fullName == "$fName"  and $serviceNumber == "$serviceNumber" ){

                    session_start();

                    $_SESSION['username'] = $fullName;

                    $_SESSION['rank'] = $rank;

                    echo "<script>window.location = 'checkOut.php'; </script>";

                    }else{?>

                        <script>
                            $(function(){
                                $("#errMsg").html("Login failed. Invalid credentials.").css({"color":"red","text-align":"center"});
                            });
                        </script>

                  <?php  }
                }
            }else{?>

                <script>
                     $(function(){
                         $("#errMsg").html("Login failed. Invalid credentials.").css({"color":"red","text-align":"center"});
                         var blink = setInterval(function(){
                             $("#errMsg").animate({"opacity":0.2}, 500);
                             $("#errMsg").animate({"opacity":1}, 500);
                         },1000);
                     });
                </script>

           <?php }
        }
    
    }
?>