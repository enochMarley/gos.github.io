<!--This is the group work of GAF DIT 2016 INTERNSHIP GROUP(SUB GROUP 3).-->
<!--All syntaxes are well documented for reusability-->
<!--
    Group members
    
    codes: Enoch Sowah
    codes(assistant): David Tettey, Godwin Dorglo, Louis Dadzie
    graphics: Eric Samoah
    graphics(assistant): Benedict Mensah
    
-->
<html>
    <head>
         <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="css/material.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
            .navbar{
                background: transparent;
                border: 1px solid transparent;
                transition: all 0.4s ease-in-out;
            }
            .navbar-brand,#menu{ 
                color: #111;
                font-weight: bold;
            }
            .mainBody{
                margin-top:5%;
                background: #fff;
            }
            #footerTitle{
              color: yellow;
            }
            #footerRow p,#footerRow p a{
              color: #fff;
            }
            #socImg{
                height: 20px;
                width: 20px;
            }
            #footerRow{
                background: #032E07;
            }
            #pageTitle{
                text-align: center;
            }
            #contactForm{
             border-right: 1px solid #c0c0c0;   
            }
            #contactForm input{
                width: 90%;
                margin-left: 5%;
                height: 40px;
            }
            #contactForm textarea{
                width: 90%;
                height: 200px;
                margin-left: 5%;
            }
            #contactForm label{
                margin-left: 5%;
            }
            #contactForm button{
                float: right;
                margin-right: 5%;
            }
            #contactMap{
                height: 300px;
                width: 90%;
                margin-left: 2%;
            }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                <a class="navbar-brand" href="#"><span id="brand">GAF ONLINE SHOP</span></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php" id="menu">Home</a></li>
                <li><a href="GOS_Shop.php" id="menu">Shop</a></li>
                <li><a href="GOS_Contact.php" id="menu" style="text-decoration:underline">Contact Us</a></li>
                <li><a href="GOS_About.php" id="menu">About Us</a></li>
              </ul>
            </div>
          </div>
        </nav>
        
        
        
     <!--Begining of main body-->
        <div class="container-fluid mainBody"><br/><br/>
            <div><h3 id="pageTitle">CONTACT US</h3></div>
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    
                    <form id="contactForm">
                        <label>Please leave a message</label><br/><br/>
                        <label>Name:</label><br/>
                        <input type="text" name="username"><br/><br/>
                        
                        <label>Email Address:</label><br/>
                        <input type="email" name="email"><br/><br/>
                        
                        <label>Contact Number:</label><br/>
                        <input type="number" name="number"><br/><br/>
                        
                        <label>Message:</label><br/>
                        <textarea type="text" name="username"></textarea><br/><br/>
                        
                        <button> Send Message </button>
                    </form>
                </div>
                <div class="col-md-6 col-xs-12">
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                               <label>Contact Information</label>
                               <p ><span class="glyphicon glyphicon-phone"></span> +1111111111</p>
                               <p><span class="glyphicon glyphicon-phone-alt"></span> +1111111111</p>
                               <p><span class="glyphicon glyphicon-earphone"></span> +1111111111</p>
                               <p><span class="glyphicon glyphicon-envelope"></span> +1111111111</p>
                               <p><span class="glyphicon glyphicon-globe"></span> +1111111111</p>
                            </div>
                            <div class="col-md-6 col-xs-12">
                               <label>Follow Us On Social Media</label>
                               <p><img src="images/face%20book.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                               <p><img src="images/instagram.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                               <p><img src="images/linked%20in.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                               <p><img src="images/twitter.png" id="socImg"><a href=""> @GAFOnlineShop</a></p>
                               <p><img src="images/youtube.png" id="socImg"><a href=""> GAF Online Shop</a></p><br>
                            </div>
                        </div>
                    
                        <div class="row"> 
                            <label>You Can Find Us Here</label>
                            <div><img src="images/map.PNG" id="contactMap"></div>
                        </div>
                </div>
            </div><br/><br/>
            
            <div class="row" id="footerRow">
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Contact Us</h6>
                          <p ><span class="glyphicon glyphicon-phone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-phone-alt"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-earphone"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-envelope"></span> +1111111111</p>
                           <p><span class="glyphicon glyphicon-globe"></span> +1111111111</p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Follow Us On Social Media</h6>
                          <p><img src="images/face%20book.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/instagram.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/linked%20in.png" id="socImg"><a href=""> GAF Online Shop</a></p>
                           <p><img src="images/twitter.png" id="socImg"><a href=""> @GAFOnlineShop</a></p>
                           <p><img src="images/youtube.png" id="socImg"><a href=""> GAF Online Shop</a></p><br>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Navigate Other Pages</h6>
                          <p><a href="index.php"> GOS Home</a></p>
                          <p><a href="GOS_Shop.php"> GOS Shop</a></p>
                          <p><a href="GOS_Contact.php"><span class="glyphicon glyphicon-asterisk"></span> GOS Contact</a></p>
                        </div>
                        <div class="col-md-3 col-xs-12">
                          <h6 id="footerTitle">Copyright</h6>
                          <p>This e-commerce site is a sole property of Ghana Armed Forces.<br/>
                            No person under any condition should use any information or part of this website without the 
                            prior notice of Ghana Armed Forces.<br/>Any culprit will be dealt with accordingly.<br/>GAF &copy; 2016</p>
                        </div>
                    </div>   
        </div>
     <!--end of main body-->
    
    <script>
        $(function(){
            
            var limit = $(".navbar").height();      //get the height of the nav bar
            
            $(window).on("scroll",function(){       //add an event listener to the browser window
                
                if($(this).scrollTop() >= limit){ //if the scrolled space >= (navbarHeight *11),
                    
                    $(".navbar").css("background","#032E07"); //change the background of the navbar to 'dirty green'
                    
                    $(".navbar-brand, #menu").css("color","#fff");// change the color of the items on navbar to white
                    
                }else{                                  //else if not so,
                    
                    $(".navbar").css("background","transparent"); //use the original style for the navbar
                    
                    $(".navbar-brand, #menu").css("color","#111");//use the original style fot items on navbar
                    
                }
            });
            
        });    
    </script>
    </body>
</html>