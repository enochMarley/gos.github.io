<?php
    include("../includes/dbConnect.php");
        
            $itemId = $_POST['itemId'];
            $itemTitle = $_POST['itemTitle'];
            $itemPrice = $_POST['itemPrice'];
            $itemImage = $_POST['itemImage'];
            $itemQuantity = $_POST['itemQuantity'];
            $itemSize = $_POST['itemSize'];
            $userIp = $_POST['userIp'];

            $itemTotalPrice = $itemPrice * $itemQuantity;

            $checkQuery = "select * from cart where itemId = $itemId and userIp = '$userIp' ;";

            $result1 = mysqli_query($con,$checkQuery);

            if(mysqli_num_rows($result1) > 0){
                echo "";
            }else{
                $putInto = "insert into cart(itemId,userIp,itemTitle,itemImg,itemPrice,itemQuantity,itemTotalPrice,itemSize)             values($itemId,'$userIp','$itemTitle','$itemImage',$itemPrice,$itemQuantity,$itemTotalPrice,'$itemSize');";

                $result2 = mysqli_query($con,$putInto);
            }


?>