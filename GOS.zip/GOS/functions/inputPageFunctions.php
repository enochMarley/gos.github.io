<?php

    include("../includes/dbConnect.php");

//display the categories in an select element
    function displayProductCategory(){
        
        global $con;
        
        $query = "select * from categories";
        
        $result = mysqli_query($con, $query);
        
        while($row = mysqli_fetch_assoc($result)){
            
            $cat_id = $row['catId'];
            
            $cat_title = $row['catTitle'];
            
            echo " <option value='$cat_id'>$cat_title</option> ";
        }
    }

        
    //display the types in an select element
    function displayProductTypes(){
        
        global $con;
        
        $query = "select * from types";
        
        $result = mysqli_query($con, $query);
        
        while($row = mysqli_fetch_assoc($result)){
            
            $type_id = $row['typeId'];
            
            $type_title = $row['typeTitle'];
            
            echo " <option value='$type_id'>$type_title</option> ";
        }
    }

?>