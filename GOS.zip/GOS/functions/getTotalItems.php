<?php
    
    function getUserIp(){
        $ip = $_SERVER['REMOTE_ADDR'];
        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        return $ip;
    } 
    
    include("../includes/dbConnect.php");

    $userIp = getUserIp();
    $query = "select * from cart where userIp = '$userIp' ;";
    $result = mysqli_query($con,$query);
    if(mysqli_num_rows($result) > 0){
        $totalItems = mysqli_num_rows($result);
    }else{
        $totalItems = 0;
    }
    
    echo $totalItems;

?>