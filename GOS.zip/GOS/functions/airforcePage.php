<?php

    function showAirforceUniforms(){
        global $con;
        $userIp = getUserIp();
        $con = mysqli_connect("localhost","root","","gos");
        $query = "select * from items where itemCat = 3 and itemType = 1 or itemCat = 3 and itemType = 2 or itemCat = 3 and itemType = 4 or itemCat = 3 and itemType = 11";
        $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0 ){
            while($row = mysqli_fetch_assoc($result)){
               
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemCat = $row['itemCat'];
                $itemType = $row['itemType'];
                $itemPrice = $row['itemPrice'];
                $itemDesc = $row['itemDescription'];
                $itemImg = $row['itemImage']; 
            
                echo"  <div class='col-md-4 col-xs-12'id='prodDiv'>
                        <br/><div class='row'>
                            <div class='col-xs-12 col-md-6'>
                                
                                <input type='hidden' name='itemId' value='$itemId' id='itemId".$itemId."'>
                                <input type='hidden' name='itemTitle' value='$itemTitle' id='itemTitle".$itemId."'>
                                <input type='hidden' name='itemPrice' value='$itemPrice' id='itemPrice".$itemId."'>
                                <input type='hidden' name='itemImage' value='$itemImg' id='itemImg".$itemId."'>
                                <input type='hidden' name='userIp' value='$userIp' id='userIp".$itemId."'>
                                <b>$itemTitle</b><br/>
                                <image src='admin/images/$itemImg' id='prodImg' height='200' width='200'><br/>
                            </div>
                            <div class='col-xs-12 col-md-6'>
                                <p><b>Description:</b> <br/>$itemDesc</p>
                                <p><b>Price:</b> GH&cent; $itemPrice </p>
                                <p><b>Quantity</b> <input type='number' id='qInput".$itemId."' min='1' name='itemQuantity' required style='width:50%;height:20px;'></p>
                                <p><b>Size</b> <select name='itemSize' id='itemSize".$itemId."'>
                                                <option selected disabled value='not specified'>Select Size</option>
                                                <option value='Small'>S</option>
                                                <option value='Medium'>M</option>
                                                <option value='Large'>L</option>
                                                <option value='ExtraLarge'>XL</option>
                                                <option value='ExtraExtraLarge'>XXL</option>
                                              </select></p>";
                                
                                $checkQuery = "select * from cart where itemId = $itemId and userIp = '$userIp' ;";

                                $result1 = mysqli_query($con,$checkQuery);

                                if(mysqli_num_rows($result1) > 0){
                                    echo "<button type='submit' id='remove".$itemId."'>Added to cart</button><br/>";
                                }else{
                                    echo "<button type='submit' id='add".$itemId."' onclick='sendToCart(".$itemId.")'>Add to cart</button><br/>";
                                }
                
                                
                           echo" 
                            </div>
                        </div>
                    </div>";
                        }

        }else{
            echo "<h3 id='errMsg'>Sorry, no item has been selected.</h3>";
        }
        
    }


    function showAirforceShoes(){
        global $con;
        $userIp = getUserIp();
        $con = mysqli_connect("localhost","root","","gos");
        $query = "select * from items where itemCat = 3 and itemType  = 13 or itemCat = 3 and itemType = 14 or itemCat = 3 and itemType = 15";
        $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0 ){
            while($row = mysqli_fetch_assoc($result)){
               
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemCat = $row['itemCat'];
                $itemType = $row['itemType'];
                $itemPrice = $row['itemPrice'];
                $itemDesc = $row['itemDescription'];
                $itemImg = $row['itemImage']; 
            
                echo"  <div class='col-md-4 col-xs-12'id='prodDiv'>
                        <br/><div class='row'>
                            <div class='col-xs-12 col-md-6'>
                                
                                <input type='hidden' name='itemId' value='$itemId' id='itemId".$itemId."'>
                                <input type='hidden' name='itemTitle' value='$itemTitle' id='itemTitle".$itemId."'>
                                <input type='hidden' name='itemPrice' value='$itemPrice' id='itemPrice".$itemId."'>
                                <input type='hidden' name='itemImage' value='$itemImg' id='itemImg".$itemId."'>
                                <input type='hidden' name='userIp' value='$userIp' id='userIp".$itemId."'>
                                <b>$itemTitle</b><br/>
                                <image src='admin/images/$itemImg' id='prodImg' height='200' width='200'><br/>
                            </div>
                            <div class='col-xs-12 col-md-6'>
                                <p><b>Description:</b> <br/>$itemDesc</p>
                                <p><b>Price:</b> GH&cent; $itemPrice </p>
                                <p><b>Quantity</b> <input type='number' id='qInput".$itemId."' min='1' name='itemQuantity' required style='width:50%;height:20px;'></p>
                                <p><b>Size</b> <select name='itemSize' id='itemSize".$itemId."'>
                                                <option selected disabled value='not specified'>Select Size</option>
                                                <option value='Small'>S</option>
                                                <option value='Medium'>M</option>
                                                <option value='Large'>L</option>
                                                <option value='ExtraLarge'>XL</option>
                                                <option value='ExtraExtraLarge'>XXL</option>
                                              </select></p>";
                                
                                $checkQuery = "select * from cart where itemId = $itemId and userIp = '$userIp' ;";

                                $result1 = mysqli_query($con,$checkQuery);

                                if(mysqli_num_rows($result1) > 0){
                                    echo "<button type='submit' id='remove".$itemId."'>Added to cart</button><br/>";
                                }else{
                                    echo "<button type='submit' id='add".$itemId."' onclick='sendToCart(".$itemId.")'>Add to cart</button><br/>";
                                }
                
                                
                           echo" 
                            </div>
                        </div>
                    </div>";
                        }

        }else{
            echo "<h3 id='errMsg'>Sorry, no item has been selected.</h3>";
        }
        
    }

    function showAirforceSocks(){
        global $con;
        $userIp = getUserIp();
        $con = mysqli_connect("localhost","root","","gos");
        $query = "select * from items where itemCat = 3 and itemType = 5 or itemCat = 3 and itemType = 6 or itemCat = 3 and itemType = 7";
        $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0 ){
            while($row = mysqli_fetch_assoc($result)){
               
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemCat = $row['itemCat'];
                $itemType = $row['itemType'];
                $itemPrice = $row['itemPrice'];
                $itemDesc = $row['itemDescription'];
                $itemImg = $row['itemImage']; 
            
                echo"  <div class='col-md-4 col-xs-12'id='prodDiv'>
                        <br/><div class='row'>
                            <div class='col-xs-12 col-md-6'>
                                
                                <input type='hidden' name='itemId' value='$itemId' id='itemId".$itemId."'>
                                <input type='hidden' name='itemTitle' value='$itemTitle' id='itemTitle".$itemId."'>
                                <input type='hidden' name='itemPrice' value='$itemPrice' id='itemPrice".$itemId."'>
                                <input type='hidden' name='itemImage' value='$itemImg' id='itemImg".$itemId."'>
                                <input type='hidden' name='userIp' value='$userIp' id='userIp".$itemId."'>
                                <b>$itemTitle</b><br/>
                                <image src='admin/images/$itemImg' id='prodImg' height='200' width='200'><br/>
                            </div>
                            <div class='col-xs-12 col-md-6'>
                                <p><b>Description:</b> <br/>$itemDesc</p>
                                <p><b>Price:</b> GH&cent; $itemPrice </p>
                                <p><b>Quantity</b> <input type='number' id='qInput".$itemId."' min='1' name='itemQuantity' required style='width:50%;height:20px;'></p>
                                <p><b>Size</b> <select name='itemSize' id='itemSize".$itemId."'>
                                                <option selected disabled value='not specified'>Select Size</option>
                                                <option value='Small'>S</option>
                                                <option value='Medium'>M</option>
                                                <option value='Large'>L</option>
                                                <option value='ExtraLarge'>XL</option>
                                                <option value='ExtraExtraLarge'>XXL</option>
                                              </select></p>";
                                
                                $checkQuery = "select * from cart where itemId = $itemId and userIp = '$userIp' ;";

                                $result1 = mysqli_query($con,$checkQuery);

                                if(mysqli_num_rows($result1) > 0){
                                    echo "<button type='submit' id='remove".$itemId."'>Added to cart</button><br/>";
                                }else{
                                    echo "<button type='submit' id='add".$itemId."' onclick='sendToCart(".$itemId.")'>Add to cart</button><br/>";
                                }
                
                                
                           echo" 
                            </div>
                        </div>
                    </div>";
                        }

        }else{
            echo "<h3 id='errMsg'>Sorry, no item has been selected.</h3>";
        }
        
    }

    function showAirforceAccessories(){
        global $con;
        $userIp = getUserIp();
        $con = mysqli_connect("localhost","root","","gos");
        $query = "select * from items where itemCat = 3 and itemType = 16 or itemCat = 3 and itemType = 17";
        $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0 ){
            while($row = mysqli_fetch_assoc($result)){
               
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemCat = $row['itemCat'];
                $itemType = $row['itemType'];
                $itemPrice = $row['itemPrice'];
                $itemDesc = $row['itemDescription'];
                $itemImg = $row['itemImage']; 
            
                echo"  <div class='col-md-4 col-xs-12'id='prodDiv'>
                        <br/><div class='row'>
                            <div class='col-xs-12 col-md-6'>
                                
                                <input type='hidden' name='itemId' value='$itemId' id='itemId".$itemId."'>
                                <input type='hidden' name='itemTitle' value='$itemTitle' id='itemTitle".$itemId."'>
                                <input type='hidden' name='itemPrice' value='$itemPrice' id='itemPrice".$itemId."'>
                                <input type='hidden' name='itemImage' value='$itemImg' id='itemImg".$itemId."'>
                                <input type='hidden' name='userIp' value='$userIp' id='userIp".$itemId."'>
                                <b>$itemTitle</b><br/>
                                <image src='admin/images/$itemImg' id='prodImg' height='200' width='200'><br/>
                            </div>
                            <div class='col-xs-12 col-md-6'>
                                <p><b>Description:</b> <br/>$itemDesc</p>
                                <p><b>Price:</b> GH&cent; $itemPrice </p>
                                <p><b>Quantity</b> <input type='number' id='qInput".$itemId."' min='1' name='itemQuantity' required style='width:50%;height:20px;'></p>
                                <p><b>Size</b> <select name='itemSize' id='itemSize".$itemId."'>
                                                <option selected disabled value='not specified'>Select Size</option>
                                                <option value='Small'>S</option>
                                                <option value='Medium'>M</option>
                                                <option value='Large'>L</option>
                                                <option value='ExtraLarge'>XL</option>
                                                <option value='ExtraExtraLarge'>XXL</option>
                                              </select></p>";
                                
                                $checkQuery = "select * from cart where itemId = $itemId and userIp = '$userIp' ;";

                                $result1 = mysqli_query($con,$checkQuery);

                                if(mysqli_num_rows($result1) > 0){
                                    echo "<button type='submit' id='remove".$itemId."'>Added to cart</button><br/>";
                                }else{
                                    echo "<button type='submit' id='add".$itemId."' onclick='sendToCart(".$itemId.")'>Add to cart</button><br/>";
                                }
                
                                
                           echo" 
                            </div>
                        </div>
                    </div>";
                        }

        }else{
            echo "<h3 id='errMsg'>Sorry, no item has been selected.</h3>";
        }
        
    }

?>