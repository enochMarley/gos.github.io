<meta name="viewport" content="width=device-width,initial-scale=1"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen" />
<link rel="stylesheet" href="css/material.min.css">
<link rel="stylesheet" type="text/css" href="css/material.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/material.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>
    
</style>

<?php
   $con = mysqli_connect("localhost","root","","gos");

    function getUserIp(){
        $ip = $_SERVER['REMOTE_ADDR'];
        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        return $ip;
    }


    function getTotalItems(){
        global $con;

        $userIp = getUserIp();
        $query = "select * from cart where userIp = '$userIp' ;";
        $result = mysqli_query($con,$query);
        if(mysqli_num_rows($result) > 0){
            $totalItems = mysqli_num_rows($result);
        }else{
            $totalItems = 0;
        }

        echo $totalItems;
        
        
    }


    function getTotalPrice(){
        global $con;
        
        $priceArray = array();
        $userIp = getUserIp();
        $query = "select * from cart where userIp = '$userIp' ;";
        $result = mysqli_query($con,$query);
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                $price = $row['itemTotalPrice'];
                array_push($priceArray,$price);
            }
            $totalPrice = array_sum($priceArray);
        }else{
            $totalPrice = 0;
        }
         echo $totalPrice;
        
    }


    function shopCart(){
        global $con;
        $userIp = getUserIp();
        $query = "select * from cart where userIp = '$userIp' ;";
        $result = mysqli_query($con,$query);
        if(mysqli_num_rows($result) > 0){
            
          echo"  <table class='table-bordered'>
                    <tr>
                        <td>Item</td>
                        <td>Item Size</td>
                        <td>Item Price</td>
                        <td>Item Quantity</td>
                        <td>Total Item Price</td>
                        <td>Remove</td>
                    </tr>";
            while($row = mysqli_fetch_assoc($result)){
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemPrice = $row['itemPrice'];
                $itemTotalPrice = $row['itemTotalPrice'];
                $itemImg = $row['itemImg'];
                $itemSize = $row['itemSize'];
                $itemQuantity = $row['itemQuantity']; ?>
                
            
                    <tr>
                        <td><?php echo $itemTitle; ?></td>
                        <td><?php echo $itemSize; ?></td>
                        <td><?php echo $itemPrice; ?></td>
                        <td><?php echo $itemQuantity; ?></td>
                        <td><?php echo $itemTotalPrice; ?></td>
                        <td><a href='#delete<?php echo $itemId; ?>' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span></td>
                    </tr>

                    <div id="delete<?php echo $itemId; ?>" class="modal fade" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Delete Contact</h4>
                                </div>
                                <div class="modal-body"> 
                                    <form action="" method="post" id="contactEditForm">
                                        <h4>Are you sure you want to remove <b><?php echo $itemTitle ?></b> from cart?</h4><br><hr>
                                        <input type="hidden" value="<?php echo $itemId; ?>" name="hidden" id="hidden">
                                        <div class="row">
                                            <div class="col-md-9"></div>
                                            <div class="col-md-3">
                                                <button type="button" data-dismiss="modal">No</button>
                                                <button type="submit" id="add1">Yes&nbsp;</button>	
                                            </div>
                                        </div>   
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
           <?php }
            
            echo "
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><b>Sub Total</b><br/>GH&cent; ";
            getTotalPrice();
            
            echo "</td>
                  <td></td>
                    </tr>
                  </table><br/>
                  <a href='GOS_Login.php'><button id='checkOut'>Check Out</button></a>";
        }else{
            echo " <h3 style='text-align:center;'> You have not added an item to the cart </h3>";
            echo " <a href='GOS_Shop.php' style='text-align:center;'><h4>Return to shop</h4></a>";
        }
    }


function checkOut(){
        global $con;
        $userIp = getUserIp();
        $query = "select * from cart where userIp = '$userIp' ;";
        $result = mysqli_query($con,$query);
        if(mysqli_num_rows($result) > 0){
            
          echo"  <table class='table-bordered'>
                    <tr>
                        <td>Item</td>
                        <td>Item Price</td>
                        <td>Remove</td>
                    </tr>";
            while($row = mysqli_fetch_assoc($result)){
                $itemId = $row['itemId'];
                $itemTitle = $row['itemTitle'];
                $itemPrice = $row['itemPrice'];
                $itemImg = $row['itemImg']; ?>
                
            
                    <tr>
                        <td><?php echo $itemTitle; ?></td>
                        <td><?php echo $itemPrice; ?></td>
                        <td><a href='#delete<?php echo $itemId; ?>' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span></td>
                    </tr>

                    <div id="delete<?php echo $itemId; ?>" class="modal fade" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Delete Contact</h4>
                                </div>
                                <div class="modal-body"> 
                                    <form action="" method="post" id="contactEditForm">
                                        <h4>Are you sure you want to remove <b><?php echo $itemTitle ?></b> from cart?</h4><br><hr>
                                        <input type="hidden" value="<?php echo $itemId; ?>" name="hidden" id="hidden">
                                        <div class="row">
                                            <div class="col-md-9"></div>
                                            <div class="col-md-3">
                                                <button type="button" data-dismiss="modal">No</button>
                                                <button type="submit" id="add1">Yes&nbsp;</button>	
                                            </div>
                                        </div>   
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
           <?php }
            
            echo "
                    <tr>
                        <td></td>
                        
                        <td><b>Sub Total</b><br/>GH&cent; ";
            getTotalPrice();
            
            echo "</td>
                  <td></td>
                    </tr>
                  </table><br/>
                  <a href=''><button id='checkOut'>Check Out</button></a>";
        }else{
            echo " <h3 style='text-align:center;'> You have not added an item to the cart </h3>";
            echo " <a href='GOS_Shop.php' style='text-align:center;'><h4>Return to shop</h4></a>";
        }
    }


    


?>