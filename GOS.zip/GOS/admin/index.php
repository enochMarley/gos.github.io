<html>
    <head>
        <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="../css/material.min.css">
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <style>
            #pageHeader{
                text-align: center;
                color: #fff;
            }
            #header{
                background: #032E07;
            }
            #pageTitle{
                text-align: center;
            }
            #loginForm{
                border: 1px solid #c0c0c0;
                border-radius: 5px;
                background: #032E07;
            }
            #loginForm input{
                width: 90%;
                height: 40px;
                margin-left: 5%;
            }
            #loginForm select{
                width: 50%;
                margin-left: 5%;
            }
            #loginForm button{
                width: 90%;
                margin-left: 5%;
            }
            #loginForm label{
                margin-left: 5%;
                color: #fff;
            }
        </style>
    </head>
    <body>
        <div class="container-fluid" id="header">
            <div class="row">
                <div><h2 id="pageHeader">ADMIN LOGIN</h2></div>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <h4 id="pageTitle">Are you an admin? If yes, please login to proceed</h4><br/>
                <div class="col-md-4"></div>
                <div class="col-md-4 col-xs-12">
                    <form id="loginForm" action="" method="post">
                        <br/>
                        <label>Username:</label><br/>
                        <input type="text" name="username" required><br/><br/>
                        
                        <label>Password:</label><br/>
                        <input type="password" name="password" required><br/><br/><br/>
                        
                        <button type="submit">Login</button><br/><br/><br/>
                        <p id="errMsg"></p>
                    </form>
                    <br/><br/><br><br><br/><br/>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </body>
</html>
<?php

    include("../includes/dbConnect.php");
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if(isset($username) and isset($password)){
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            
            $query = "select * from admin where adminUsername = '$username' and adminPassword = '$password' ;";

            $result= mysqli_query($con,$query);

            if(mysqli_num_rows($result) > 0){

                $row = mysqli_fetch_assoc($result);

                $id = $row['id'];

                $aName = $row['adminUsername'];

                $aPassword = $row['adminPassword'];

                if($_SERVER['REQUEST_METHOD'] == "POST"){

                    if($username == "$aName"  and $password == "$aPassword" ){

                    session_start();

                    $_SESSION['adminUsername'] = $username;

                    echo "<script>window.location = 'adminPanel.php'; </script>";

                    }else{?>

                        <script>
                            $(function(){
                                $("#errMsg").html("Login failed. Invalid credentials.").css({"color":"red","text-align":"center"});
                            });
                        </script>

                  <?php  }
                }
            }else{?>

                <script>
                     $(function(){
                         $("#errMsg").html("Login failed. Invalid credentials.").css({"color":"red","text-align":"center"});
                         var blink = setInterval(function(){
                             $("#errMsg").animate({"opacity":0.2}, 500);
                             $("#errMsg").animate({"opacity":1}, 500);
                         },1000);
                     });
                </script>

           <?php }
        }
    
    }
?>