<!doctype>
<?php
    include("../functions/inputPageFunctions.php"); 
    session_start();
?>
<html>
    <head>
        <title>GAF Online Shop</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="../css/material.min.css">
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <style>
            #pageTitle,#user{
                text-align: center;
                 color: #fff;
            }
            #header{
                background: #032E07;
            }
            #contentDiv{
                height: 600px;
                border: 1px solid #c0c0c0;
                z-index: 999;
            }
            #menuDiv{
                height: 100%;
                background: #032E07;
                border: 1px solid #c0c0c0;
                border-right: none;
            }
            #itemDiv{
                border: 1px solid #c0c0c0;
                height: 100%;
                overflow-y: auto;
                border-left: none;
            }
            a,a:hover{text-decoration: none;}
            
            a#ulList{
                display: block;
                width: 120%;
                height: 50px;
                background: inherit;
                float: left;
                margin-left: -10%; 
                
            }
            a#ulList p{
                line-height: 50px;
                font-size: 20px;
                text-align: center;
            }
            a#ulList:nth-child(1){
                display: block;
                width: 120%;
                height: 50px;
                background: #fff;
                float: left;
                margin-left: -9%;
            }
            form{
                background: #fff;
                opacity: 0.9;
                width: 90%;
                margin-left: 5%;
            }
            label{
                color: #111;
                margin-left: 5%;
            }
            input[type="text"],input[type="number"]{
                width: 90%;
                margin-left: 5%;
                height: 40px;
                border: 1px solid #c0c0c0;
                background: #fff;
                color: #111;
                
            }
            textarea
                {
                width: 90%;
                margin-left: 5%;
                height: 80px;
                border: 1px solid #c0c0c0;
                background: #fff;
                color: #111;
            }
            button{
                margin-left: 5%;
            }
            select, input[type="file"]{
                margin-left: 5%;
            }
            #pageIntro{text-align: center;}
            hr{width: 80%;margin-left: 10%;}
        </style>
    </head>
    <body>
        <div class="container"  id="header">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4"><h4 id="pageTitle">ADMIN DASHBOARD</h4></div>
                
                <div class="col-md-2"><h5 id="user"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['adminUsername']; ?></h5></div>
                <div class="col-md-2"><a href="logout.php"><h5 id="user">Logout</h5></a></div>
            </div>
        </div>
        <div class="container" id="contentDiv">
            <div class="row">
                <div class="col-md-2" id="menuDiv">
                    <a href="" id="ulList"><p>Cart</p></a>
                    <a href="" id="ulList"><p>Inventory</p></a>
                    <a href="" id="ulList"><p>Item Leaderboard</p></a>
                    <a href="" id="ulList"><p>Input Products</p></a>
                </div>
                <div class="col-md-10" id="itemDiv">
                    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
                        <br/>
                        <h5 id="pageIntro">Please fill the form with the appropriate details to enter product into the database</h5><hr><br/>
                        
                        <label>Item Image (png images only) :</label><br/>
                        <input type="file" accept="image/x-png" name="prodImg"><br/><br/>

                        <label>Item Category:</label><br/>
                        <select name="itemcategory">
                            <option selected disabled>Please select item category</option>
                            <?php displayProductCategory(); ?>
                        </select><br/><br/>

                        <label>Item Type:</label><br/>
                        <select name="itemType">
                            <option selected disabled>Please select item type</option>
                            <?php displayProductTypes(); ?>
                        </select><br/><br/>

                        <label>Item title:</label><br/>
                        <input type="text" name="itemTitle"/><br/><br/>

                        <label>Item Price:</label><br/>
                        <input type="number" name="itemPrice"><br/><br/>

                        <label>Item Description:</label><br/>
                        <textarea name="itemDescription"></textarea><br/><br/>

                        <label>Item keywords:</label><br/>
                        <input name="itemKeywords" type="text"><br/><br/>

                        <button type="submit" name="submit">Input Product</button><br/><br/>

                    </form>
                </div>
            </div>
        </div>
    </body>
</html>


<?php
    
    define ('SITE_ROOT', realpath(dirname(__FILE__)));

    $itemTitle = $_POST['itemTitle'];

    $itemCat = $_POST['itemcategory'];

    $itemType = $_POST['itemType'];

    $itemPrice = $_POST['itemPrice'];

    $itemDesc = $_POST['itemDescription'];

    $itemKeyword = $_POST['itemKeywords'];

    $itemImg = basename($_FILES['prodImg']['name']);

    $itemImg_tempName = $_FILES['prodImg']['tmp_name'];
    
    if(isset($itemTitle) && isset($itemCat) && isset($itemType) && isset($itemPrice) && isset($itemDesc) && isset($itemKeyword) && isset($itemImg) && isset($itemImg_tempName)){
        
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            
            $query = "insert into items(itemCat,itemType,itemTitle,itemPrice,itemDescription,itemImage,itemKeywords) values('$itemCat','$itemType','$itemTitle','$itemPrice','$itemDesc','$itemImg','$itemKeyword');";

            $result = mysqli_query($con, $query);

            if($result){

                move_uploaded_file($itemImg_tempName, SITE_ROOT."/images/$itemImg");

                echo "<script> alert('Product Input Successful'); </script>";

                echo "<script>window.open(inputProducts.php,'_self');</script>";

            }else{

                echo "";

            }
            
        }
        
        
    }

    

?>