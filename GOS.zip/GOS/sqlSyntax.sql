create database gos;
create table gos.items(itemId int auto_increment not null primary key,itemCat int not null,itemType int not null, itemTitle varchar(255) not null,itemPrice int not null,itemDescription text not null,itemImage text not null, itemKeywords text not null);

create table gos.categories(catId int not null primary key auto_increment,catTitle varchar(200) not null);

create table gos.types(typeId int not null auto_increment primary key,typeTitle varchar(200) not null);

insert into gos.categories(catTitle) values("Army");

insert into gos.categories(catTitle) values("Navy"); 

insert into gos.categories(catTitle) values("AirForce");

insert into gos.categories(catTitle) values("CivilianEmployee");

insert into gos.types(typeTitle) values("Full Uniforms");insert into gos.types(typeTitle) values("Ceremonial Uniforms");insert into gos.types(typeTitle) values("Officers Uniforms");insert into gos.types(typeTitle) values("Overall Uniforms");insert into gos.types(typeTitle) values("Caps");insert into gos.types(typeTitle) values("Hats");insert into gos.types(typeTitle) values("Berets");insert into gos.types(typeTitle) values("Civilian Shirts");insert into gos.types(typeTitle) values("Civilian Skirts");insert into gos.types(typeTitle) values("Civilian Trousers");insert into gos.types(typeTitle) values("T-Shirts");insert into gos.types(typeTitle) values("Civilian Shoes");insert into gos.types(typeTitle) values("Officers Shoes");insert into gos.types(typeTitle) values("Desert Boots");insert into gos.types(typeTitle) values("Black Boots");insert into gos.types(typeTitle) values("Socks");insert into gos.types(typeTitle) values("Accessories");

create table gos.cart(itemId int not null,userIp varchar(25) not null,itemTitle varchar(100) not null,itemSize varchar(30) not null,itemImg text,itemPrice float not null,itemQuantity int not null default 1,itemTotalPrice float not null); 

create table gos.users(userId int not null AUTO_INCREMENT PRIMARY KEY,fullName varchar(100) not null, serviceNumber varchar(10) not  null, rank varchar(20) not null);

create table gos.admin(id int AUTO_INCREMENT PRIMARY KEY NOT null,adminUsername varchar(100) not null,adminPassword varchar(100) not null);